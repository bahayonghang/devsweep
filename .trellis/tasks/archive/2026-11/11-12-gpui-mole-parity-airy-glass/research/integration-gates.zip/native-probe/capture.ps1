﻿# Native capture for the Clean page rework (bahayonghang/devsweep#6). Derived
# from ../../11-16-gpui-material-recipe-spike/evidence/capture.ps1: one call is
# one launch of the binary, the window is captured with PrintWindow (its own
# pixels, no desktop), and probes read the saved bitmap.
#
# Nothing here changes a Windows setting. Environment variables for the app
# (DEVSWEEP_CLEAN_REVIEW_FIXTURE, LOCALAPPDATA, ...) are set by the caller and
# inherited by the child process only.
#
#   -Name n          log prefix and default file stem
#   -BinaryPath p    executable to launch
#   -OutDir d        where PNG files and capture.txt go
#   -ClientWidth n   resize the client area to n x m logical px after launch
#   -ClientHeight m
#   -Steps 'a;b;c'   run in order after the window settles:
#       shot:stem          PrintWindow to <stem>.png
#       key:9              post key down/up for a virtual-key code (9 = Tab)
#       shiftkey:9         the same with Shift held (real key state is not
#                          changed; GPUI reads GetKeyState, so this is posted
#                          as a best effort and logged)
#       click:x,y          post a left click at a logical client point
#       move:x,y           post a mouse move to a logical client point
#       cursor:x,y         move the real cursor there (hover needs it: GPUI
#                          tracks WM_MOUSELEAVE); the old position is restored
#                          by `cursorback`
#       cursorback
#       wait:ms
#       probe:label:x,y    colour of a logical client point in the last shot
param([Parameter(Mandatory)][string]$Name,
      [Parameter(Mandatory)][string]$BinaryPath,
      [Parameter(Mandatory)][string]$OutDir,
      [string]$Launch='',
      [int]$ClientWidth=0,
      [int]$ClientHeight=0,
      [string]$Steps='shot')
$ErrorActionPreference = 'Stop'
trap {
    [IO.File]::AppendAllText((Join-Path $OutDir 'boot-error.txt'),($_ | Out-String) + $_.ScriptStackTrace)
    exit 1
}
[IO.File]::WriteAllText((Join-Path $OutDir 'started.txt'),$Name)
Add-Type -AssemblyName System.Drawing,System.Windows.Forms
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class CleanWindow {
    [DllImport("user32")] public static extern bool PrintWindow(IntPtr w, IntPtr dc, uint flags);
    [DllImport("user32")] public static extern bool PostMessage(IntPtr w, uint msg, IntPtr wp, IntPtr lp);
    [DllImport("user32")] public static extern bool GetWindowRect(IntPtr w, out Rect r);
    [DllImport("user32")] public static extern bool GetClientRect(IntPtr w, out Rect r);
    [DllImport("user32")] public static extern bool ClientToScreen(IntPtr w, ref Point p);
    [DllImport("user32")] public static extern uint GetDpiForWindow(IntPtr w);
    [DllImport("user32")] public static extern bool SetWindowPos(IntPtr w, IntPtr z, int x, int y, int cx, int cy, uint flags);
    [DllImport("user32")] public static extern bool SetProcessDpiAwarenessContext(IntPtr ctx);
    [DllImport("user32")] public static extern bool GetCursorPos(out Point p);
    [DllImport("user32")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32")] public static extern bool SetForegroundWindow(IntPtr w);
    private delegate bool EnumerateWindow(IntPtr w, IntPtr l);
    [DllImport("user32")] private static extern bool EnumWindows(EnumerateWindow fn, IntPtr param);
    [DllImport("user32")] private static extern uint GetWindowThreadProcessId(IntPtr w, out uint pid);
    [DllImport("user32",CharSet=CharSet.Unicode)] private static extern int GetWindowText(IntPtr w, System.Text.StringBuilder text, int max);
    public static IntPtr ProductWindow(int owner) {
        IntPtr found = IntPtr.Zero;
        EnumWindows(delegate(IntPtr w, IntPtr l) {
            uint pid; GetWindowThreadProcessId(w,out pid); if(pid!=owner) return true;
            var title = new System.Text.StringBuilder(256); GetWindowText(w,title,256);
            Rect r; GetClientRect(w,out r);
            if(title.ToString()=="DevSweep" && r.right>400 && r.bottom>250) {found=w; return false;}
            return true;
        },IntPtr.Zero);
        return found;
    }
    [DllImport("kernel32")] static extern uint GetCurrentThreadId();
    [DllImport("user32")] static extern bool AttachThreadInput(uint from, uint to, bool attach);
    [DllImport("user32")] static extern bool GetKeyboardState(byte[] state);
    [DllImport("user32")] static extern bool SetKeyboardState(byte[] state);
    [DllImport("user32")] static extern IntPtr SendMessageTimeout(IntPtr w,uint msg,IntPtr wp,IntPtr lp,uint flags,uint ms,out UIntPtr result);
    public static bool PrivateChord(IntPtr w, int pid, int key) {
        uint owner;
        uint to = GetWindowThreadProcessId(w,out owner), from = GetCurrentThreadId();
        if (pid != owner || !AttachThreadInput(from,to,true)) return false;
        var previous = new byte[256];
        try {
            if (!GetKeyboardState(previous)) return false;
            var held=(byte[])previous.Clone();
            held[0x10]=held[0xA0]=0x80;
            if (!SetKeyboardState(held)) return false;

            bool head=PostMessage(w,0x100,(IntPtr)key,(IntPtr)1); System.Threading.Thread.Sleep(300); return head
                && PostMessage(w,0x101,(IntPtr)key,(IntPtr)(-1073741823));
        } finally { SetKeyboardState(previous); AttachThreadInput(from,to,false); }
    }
    public struct Point { public int x,y; }
    public struct Rect { public int left,top,right,bottom; }
}
'@
[void][CleanWindow]::SetProcessDpiAwarenessContext([IntPtr](-4))
$binary = (Resolve-Path -LiteralPath $BinaryPath).Path
[void][IO.Directory]::CreateDirectory($OutDir)
$utf8 = [Text.UTF8Encoding]::new($false)
$log = [Collections.Generic.List[string]]::new()
function Record([string]$line) { $log.Add("$Name $line"); Write-Output "$Name $line" }
function WindowRect { $r = New-Object CleanWindow+Rect; [void][CleanWindow]::GetWindowRect($hwnd,[ref]$r); $r }
function ClientRect { $r = New-Object CleanWindow+Rect; [void][CleanWindow]::GetClientRect($hwnd,[ref]$r); $r }
$script:last = $null
function Capture([string]$stem) {
    Start-Sleep -Milliseconds 500
    $r = WindowRect
    $bmp = [Drawing.Bitmap]::new($r.right-$r.left,$r.bottom-$r.top)
    $g = [Drawing.Graphics]::FromImage($bmp)
    $dc = $g.GetHdc()
    try { $ok = [CleanWindow]::PrintWindow($hwnd,$dc,2) } finally { $g.ReleaseHdc($dc); $g.Dispose() }
    if (-not $ok) { $bmp.Dispose(); throw 'PrintWindow failed' }
    $bmp.Save((Join-Path $OutDir "$stem.png"),[Drawing.Imaging.ImageFormat]::Png)
    if ($script:last) { $script:last.Dispose() }
    $script:last = $bmp
    Record "captured $stem.png $($r.right-$r.left)x$($r.bottom-$r.top)"
}
# Client origin inside the captured window bitmap.
function ClientOffset {
    $p = New-Object CleanWindow+Point; [void][CleanWindow]::ClientToScreen($hwnd,[ref]$p)
    $r = WindowRect
    @(($p.x-$r.left),($p.y-$r.top))
}
function Physical([string]$xy) {
    $parts = $xy -split ','
    @([int]([double]$parts[0]*$dpi/96),[int]([double]$parts[1]*$dpi/96))
}
function LParam([int[]]$p) { [IntPtr](($p[1] -shl 16) -bor ($p[0] -band 0xffff)) }
function RunStep([string]$step) {
    $verb,$arg = $step -split ':',2
    switch ($verb) {
        'shot' { Capture $(if ($arg) { $arg } else { $Name }) }
        'key' {
            $vk=[int]$arg
            [void][CleanWindow]::PostMessage($hwnd,0x100,[IntPtr]$vk,[IntPtr]1)
            [void][CleanWindow]::PostMessage($hwnd,0x101,[IntPtr]$vk,[IntPtr]0xC0000001)
            Start-Sleep -Milliseconds 350
            Record "key $vk"
        }
        'shiftkey' {
            $ok=[CleanWindow]::PrivateChord($hwnd,$proc.Id,[int]$arg)
            Record "private Shift+$arg delivered=$ok"
            if (!$ok) { throw 'Private Shift chord input delivery failed' }
            Start-Sleep -Milliseconds 400
        }
        'click' {
            $p = Physical $arg; $l = LParam $p
            [void][CleanWindow]::PostMessage($hwnd,0x200,[IntPtr]0,$l)
            Start-Sleep -Milliseconds 120
            [void][CleanWindow]::PostMessage($hwnd,0x201,[IntPtr]1,$l)
            Start-Sleep -Milliseconds 80
            [void][CleanWindow]::PostMessage($hwnd,0x202,[IntPtr]0,$l)
            Start-Sleep -Milliseconds 700
            Record "click $arg"
        }
        'move' {
            $p = Physical $arg
            [void][CleanWindow]::PostMessage($hwnd,0x200,[IntPtr]0,(LParam $p))
            Start-Sleep -Milliseconds 400
            Record "move $arg"
        }
        'cursor' {
            $p = Physical $arg
            $s = New-Object CleanWindow+Point; $s.x=$p[0]; $s.y=$p[1]
            [void][CleanWindow]::ClientToScreen($hwnd,[ref]$s)
            if (-not $script:cursor) { $c = New-Object CleanWindow+Point; [void][CleanWindow]::GetCursorPos([ref]$c); $script:cursor=$c }
            [void][CleanWindow]::SetWindowPos($hwnd,[IntPtr](-1),0,0,0,0,0x13)
            [void][CleanWindow]::SetCursorPos($s.x-2,$s.y-2); Start-Sleep -Milliseconds 80
            [void][CleanWindow]::SetCursorPos($s.x,$s.y); Start-Sleep -Milliseconds 500
            Record "cursor $arg"
        }
        'cursorback' {
            [void][CleanWindow]::SetWindowPos($hwnd,[IntPtr](-2),0,0,0,0,0x13)
            if ($script:cursor) { [void][CleanWindow]::SetCursorPos($script:cursor.x,$script:cursor.y); $script:cursor=$null }
        }
        'wait' { Start-Sleep -Milliseconds ([int]$arg) }
        'uia' {
            Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes
            $root=[System.Windows.Automation.AutomationElement]::FromHandle($hwnd)
            Record "root name=$($root.Current.Name), class=$($root.Current.ClassName), framework=$($root.Current.FrameworkId), control=$($root.Current.ControlType.ProgrammaticName), pid=$($root.Current.ProcessId)"; $rows=@(foreach($item in $root.FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition)){
                $cur=$item.Current
                $row=[ordered]@{id=$cur.AutomationId; type=$cur.ControlType.ProgrammaticName; name=$cur.Name; enabled=$cur.IsEnabled; focused=$cur.HasKeyboardFocus; rect=$cur.BoundingRectangle.ToString()}
                $pattern=$null
                if ($item.TryGetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern,[ref]$pattern)) { $row.toggle=$pattern.Current.ToggleState.ToString() }
                [pscustomobject]$row
            })
            [IO.File]::WriteAllText((Join-Path $OutDir "$arg.json"),(ConvertTo-Json -InputObject $rows -Depth 4),$utf8)
            Record "uia=$arg elements=$($rows.Count)"
        }
        {$_ -in 'click-id','right-id','click-name','wait-id','focus-read'} {
            Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes
            $hit=$null
            $root=[System.Windows.Automation.AutomationElement]::FromHandle($hwnd)
            for ($attempt=0;$attempt -lt 16 -and !$hit;$attempt++) {
                $elements=$root.FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition)
                if ($verb -eq 'click-name') { $hit=@($elements|Where-Object {$_.Current.Name -like "*$arg*"} | Select-Object -First 1)[0] }
                else {$hit=@($elements|Where-Object {$_.Current.AutomationId -eq $arg} | Select-Object -First 1)[0]}
                if (!$hit) {Start-Sleep -Milliseconds 180}
            }
            if (!$hit) {throw "$verb requested '$arg', present ids: $(@($elements|ForEach-Object {$_.Current.AutomationId}|Where-Object {$_}) -join ',')"}
            $r=$hit.Current.BoundingRectangle
            Record "$verb id=$($hit.Current.AutomationId) label=$($hit.Current.Name) focused=$($hit.Current.HasKeyboardFocus) enabled=$($hit.Current.IsEnabled) bounds=$r"
            if ($verb -in 'wait-id','focus-read') { break }
            if (!$hit.Current.IsEnabled -or $r.IsEmpty -or $r.Width -le 0) {throw "unavailable element $arg"}
            $pt=New-Object CleanWindow+Point
            [void][CleanWindow]::ClientToScreen($hwnd,[ref]$pt)
            $x=[int]($r.Left+$r.Width/2-$pt.x); $y=[int]($r.Top+$r.Height/2-$pt.y)
            $l=LParam @($x,$y)
            $down=if($verb -eq 'right-id'){0x204}else{0x201}; $up=$down+1
            [void][CleanWindow]::PostMessage($hwnd,$down,[IntPtr]$(if($verb -eq 'right-id'){2}else{1}),$l)
            [void][CleanWindow]::PostMessage($hwnd,$up,[IntPtr]0,$l)
            Start-Sleep -Milliseconds 400
        }
        'verify-ready' {
            Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes
            $root=[System.Windows.Automation.AutomationElement]::FromHandle($hwnd)
            $nodes=$root.FindAll([System.Windows.Automation.TreeScope]::Descendants,[System.Windows.Automation.Condition]::TrueCondition)
            $found=@($nodes | Where-Object { $_.Current.IsEnabled -and $_.Current.Name -match '(Confirm move|确认移入回收站)' })
            if ($found.Count -eq 0) {throw "expected a live enabled recycle confirmation before dispatch"}
            $reviewRoots=@($nodes | Where-Object { $_.Current.AutomationId -like 'clean-row-*' })
            if (!$reviewRoots.Count -or @($reviewRoots | Where-Object { !$_.Current.AutomationId.Contains($env:DEVSWEEP_ACCEPT_ROOT) }).Count) {throw "row outside task fixture"}
            Record "ready verified confirm=$($found.Count) visible-owned-rows=$($reviewRoots.Count)"
        }
        'probe' {
            $label,$xy = $arg -split ':',2
            $p = Physical $xy; $o = ClientOffset
            $c = $script:last.GetPixel($p[0]+$o[0],$p[1]+$o[1])
            Record ("probe {0} ({1}) #{2:X2}{3:X2}{4:X2}" -f $label,$xy,$c.R,$c.G,$c.B)
        }
        default { throw "unknown step $step" }
    }
}
$sha=[Security.Cryptography.SHA256]::Create()
try { $binaryHash=[BitConverter]::ToString($sha.ComputeHash([IO.File]::ReadAllBytes($binary))).Replace('-','') } finally { $sha.Dispose() }
$personalize='HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize'
$transparency=[Microsoft.Win32.Registry]::GetValue($personalize,'EnableTransparency',$null)
$appsLight=[Microsoft.Win32.Registry]::GetValue($personalize,'AppsUseLightTheme',$null)
Record "launch=[$Launch] fixture=[$env:DEVSWEEP_CLEAN_REVIEW_FIXTURE] binary_sha256=$binaryHash os=$([Environment]::OSVersion.Version) transparency=$transparency apps_light=$appsLight"
$info = [Diagnostics.ProcessStartInfo]::new($binary)
$info.Arguments = $Launch
$info.UseShellExecute = $false
$proc = [Diagnostics.Process]::Start($info)
try {
    for ($n=0; $n -lt 150; $n++) {
        $proc.Refresh()
        if ($proc.HasExited) { throw "startup exit $($proc.ExitCode)" }
        $hwnd=[CleanWindow]::ProductWindow($proc.Id); if ($hwnd -ne [IntPtr]::Zero) { break }
        Start-Sleep -Milliseconds 200
    }
    $hwnd=[CleanWindow]::ProductWindow($proc.Id)
    if ($hwnd -eq [IntPtr]::Zero) { throw 'window missing' }
    $dpi=[CleanWindow]::GetDpiForWindow($hwnd)
    if ($ClientWidth -gt 0) {
        $w=WindowRect; $c=ClientRect
        $frameX=($w.right-$w.left)-$c.right; $frameY=($w.bottom-$w.top)-$c.bottom
        $tall=if ($ClientHeight -gt 0) { [int]($ClientHeight*$dpi/96)+$frameY } else { $w.bottom-$w.top }
        [void][CleanWindow]::SetWindowPos($hwnd,[IntPtr]::Zero,40,40,[int]($ClientWidth*$dpi/96)+$frameX,$tall,0x14)
    }
    # Blob images decode off the main thread; give them time to land.
    Start-Sleep -Milliseconds 1800
    $w=WindowRect; $c=ClientRect
    Record "dpi=$dpi window=$($w.right-$w.left)x$($w.bottom-$w.top) client=$($c.right)x$($c.bottom) logical_client=$([math]::Round($c.right*96/$dpi))x$([math]::Round($c.bottom*96/$dpi))"
    foreach ($step in ($Steps -split ';' | Where-Object { $_ })) { RunStep $step }
} catch { Record "ERROR $($_.Exception.Message)" } finally {
    if ($script:cursor) { [void][CleanWindow]::SetCursorPos($script:cursor.x,$script:cursor.y) }
    if (-not $proc.HasExited) { if ($hwnd -ne [IntPtr]::Zero) { [void][CleanWindow]::PostMessage($hwnd,0x10,[IntPtr]::Zero,[IntPtr]::Zero) }; if (-not $proc.WaitForExit(5000)) { $proc.Kill(); $proc.WaitForExit() } }
    Record "exit=$($proc.ExitCode)"
    $proc.Dispose()
    if ($script:last) { $script:last.Dispose() }
}
[IO.File]::AppendAllLines((Join-Path $OutDir 'capture.txt'),$log,$utf8)
if ($log -match ' ERROR ') { exit 1 }




