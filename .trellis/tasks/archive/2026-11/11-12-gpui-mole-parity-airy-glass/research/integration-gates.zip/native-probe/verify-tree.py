from pathlib import Path
from collections import Counter
from urllib.parse import unquote
import re, sys, json, hashlib
root=Path(__file__).resolve().parents[2]
tasks=root/'.trellis/tasks'
archive=tasks/'archive/2026-11'
name='11-12-gpui-mole-parity-airy-glass'
parent=archive/name
assert parent.is_dir() and not (tasks/name).exists()
metadata=json.loads((parent/'task.json').read_text('utf-8-sig'))
assert metadata['status']=='completed'
assert len(metadata['children'])==len(set(metadata['children']))==9
for name in metadata['children']:
    p=archive/name
    assert p.is_dir() and not (tasks/name).exists()
    sub=json.loads((p/'task.json').read_text('utf-8-sig'))
    assert sub['status']=='completed'
    assert sub['parent'] in (parent.name,metadata['id']), (name,sub['parent'])
    print('archived',name)
p=parent/'research/integration-review.md'
s=p.read_text('utf-8-sig')
for head,n in [('S',10),('C',5),('W',3),('O',2),('A',5),('T',8)]: 
    for i in range(1,n+1): assert re.search(r'^\| '+head+str(i)+r' \|',s,re.M)
assert len(re.findall(r'^\| AC[1-8] ',s,re.M))==8
broken=[]
files=[p,parent/'result.md',parent/'implement.md']+[archive/i/'result.md' for i in metadata['children'] if (archive/i/'result.md').is_file()]
for f in files:
    for path in re.findall(r'\[[^]\n]*\]\(([^)\n]+)\)',f.read_text('utf-8-sig')):
        if path.startswith(('https:','http:','#','mailto:')): continue
        loc=unquote(path.split('#')[0])
        if not (f.parent/loc).exists(): broken.append((f.name,path))
if broken: print('broken',broken)
assert not broken
matrix=s.split('## 原生截图索引',1)[1].split('## 桌面动作',1)[0]
for title in ('Clean','Software','Optimize','Analyze','Status','托盘'):
    line=next(l for l in matrix.splitlines() if l.startswith(f'| {title} |'))
    assert len(re.findall(r'\]\(',line))==4,(title,line)
print('Verified 9 children, 8 acceptance criteria, 33 gap decisions, 24 linked images and local receipt links.')
