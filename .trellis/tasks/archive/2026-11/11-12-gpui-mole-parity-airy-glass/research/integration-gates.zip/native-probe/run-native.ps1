param([Parameter(Mandatory)][string]$Binary,[Parameter(Mandatory)][string]$Run,[string]$Language="en",[string]$Theme="light",[string]$Scene="",[string]$Steps="shot:landing",[string]$Domain="Clean",[int]$Width=1240,[int]$Height=820)
$ErrorActionPreference="Stop"
$base=Join-Path (Resolve-Path "dist/verify-1120") $Run
if (Test-Path -LiteralPath $base) { throw "Run exists: $Run" }
$dirs=@("project","local/DevSweep/settings","roaming","tmp","shots")
foreach ($dir in $dirs) { New-Item -ItemType Directory -Path (Join-Path $base $dir) -Force | Out-Null }
$env:PYTHONUSERBASE=Join-Path $env:APPDATA "Python"
$env:LOCALAPPDATA=Join-Path $base "local"
$env:APPDATA=Join-Path $base "roaming"
$env:TEMP=Join-Path $base "tmp"
$env:TMP=$env:TEMP
$env:DEVSWEEP_ACCEPT_ROOT=Join-Path $base "project"
if ($Scene) { $env:DEVSWEEP_CLEAN_REVIEW_FIXTURE=$Scene }
else {
    Remove-Item Env:DEVSWEEP_CLEAN_REVIEW_FIXTURE -ErrorAction SilentlyContinue
    $project=(Get-Item -LiteralPath $env:DEVSWEEP_ACCEPT_ROOT).FullName
    if ($Domain -eq "Analyze") {
        $lengths=@(120MB,60MB,30MB)
        for ($n=0; $n -lt $lengths.Count; $n++) {
            $file=[IO.File]::Create((Join-Path $project ("analysis-{0}.bin" -f ($n+1))))
            try {$file.SetLength($lengths[$n])} finally {$file.Dispose()}
        }
    }
    if ($Domain -eq "Clean") {1..53 | ForEach-Object {
        $dir=Join-Path $project ('item-{0:d2}' -f $_)
        New-Item -ItemType Directory -Path (Join-Path $dir ".pytest_cache") | Out-Null
        [IO.File]::WriteAllText((Join-Path $dir "pyproject.toml"),"[tool.pytest.ini_options]")
        [IO.File]::WriteAllBytes((Join-Path $dir ".pytest_cache/owned.bin"),[byte[]]::new(4096))
    }
    }
    $settings=Join-Path $env:LOCALAPPDATA "DevSweep/settings"
    @{schema_version=1;roots=@($project)} | ConvertTo-Json | Set-Content -Encoding utf8NoBOM (Join-Path $settings "clean-scan-roots-v1.json")
    @{schema_version=1;language=$Language} | ConvertTo-Json | Set-Content -Encoding utf8NoBOM (Join-Path $settings "presentation-v1.json")
    @{schema_version=2;theme=$Theme;font=@{kind="system"};text_scale_percent=100;motion="reduced";planet_fps=15;status_interval_seconds=5;status_process_limit=15;hud_interval_seconds=2} | ConvertTo-Json | Set-Content -Encoding utf8NoBOM (Join-Path $settings "desktop-preferences-v2.json")
}
python dist/verify-1120/private_desktop.py powershell -NoProfile -File "$PWD/dist/verify-1120/capture.ps1" -Name $Run -BinaryPath $Binary -OutDir (Join-Path $base 'shots') -ClientWidth $Width -ClientHeight $Height -Steps $Steps
$rc=$LASTEXITCODE
if (Test-Path (Join-Path $base 'shots/capture.txt')){Get-Content -Tail 15 (Join-Path $base 'shots/capture.txt')}
else {Write-Output "Private run exit code $rc"; Get-ChildItem (Join-Path $base 'shots') | ForEach-Object { Write-Output $_.Name; if($_.Extension -eq '.txt'){ Get-Content -LiteralPath $_.FullName } }}
exit $rc

