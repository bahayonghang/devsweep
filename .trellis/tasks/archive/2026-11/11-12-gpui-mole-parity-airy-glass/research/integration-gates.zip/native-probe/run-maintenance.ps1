param([Parameter(Mandatory)][string]$Binary,[Parameter(Mandatory)][string]$Run,[string]$Language="en",[string]$Theme="light",[switch]$Mixed)
$ErrorActionPreference="Stop"
$baseSteps="uia:prime;key:9;click-id:mode-optimize;wait-id:optimize-check-dns.flush;uia:catalogue;shot:catalogue"
if ($Mixed) {
    $env:DEVSWEEP_OPTIMIZE_FIXTURE="1"
    $baseSteps+=";wait-id:optimize-isolated-fixture;click-id:optimize-check-maintenance.clock_probe;click-id:optimize-check-maintenance.retrim;click-id:optimize-check-dns.flush;click-id:optimize-batch-review;wait-id:optimize-batch-preview;uia:review;shot:review;wait-id:optimize-isolated-fixture;click-id:optimize-batch-confirm;wait-id:optimize-batch-results;uia:result;shot:result"
} else {
    Remove-Item Env:DEVSWEEP_OPTIMIZE_FIXTURE -ErrorAction SilentlyContinue
}
pwsh -NoProfile -File ./dist/verify-1120/run-native.ps1 -Binary $Binary -Run $Run -Domain Optimize -Language $Language -Theme $Theme -Steps $baseSteps
exit $LASTEXITCODE
