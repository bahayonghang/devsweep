from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
root=Path(__file__).resolve().parents[2]
tasks=root/'.trellis/tasks'
archive=tasks/'archive/2026-11'
parent_name='11-12-gpui-mole-parity-airy-glass'
def task(name):
    return next(p for p in (tasks/name,archive/name) if p.is_dir())
parent=task(parent_name)
res=parent/'research'
locales=['EN light','EN dark','ZH light','ZH dark']
short=['en-light','en-dark','zh-light','zh-dark']
paths=[
 ('Clean',task('11-12-gpui-clean-review-flow')/'evidence/integration-1120',['en-review.png','en-dark-review.png','zh-light-review.png','zh-review.png']),
 ('Software',res/'native',[f'software-{lang}-{mode}.png' for lang,mode in [('en','light'),('en','dark'),('zh-CN','light'),('zh-CN','dark')]]),
 ('Optimize',task('11-12-gpui-optimize-batch')/'evidence/native',[f'{s}-ordinary.png' for s in short]),
 ('Analyze',task('11-12-gpui-analyze-insights')/'evidence/native',['en-light-wide.png','en-dark-wide.png','zh-light-wide.png','zh-dark-narrow.png']),
 ('Status',task('11-12-gpui-tray-panel')/'evidence',[f'{s}-status.png' for s in short]),
 ('Tray',task('11-12-gpui-tray-panel')/'evidence',[f'{s}-panel.png' for s in short])]
w,h,side,top=350,225,110,45
sheet=Image.new('RGB',(side+4*w,top+6*h),'#eef0f1')
draw=ImageDraw.Draw(sheet)
font=ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf',20)
for j,title in enumerate(locales): draw.text((side+(j+.5)*w,top//2),title,fill='#24303a',font=font,anchor='mm')
for i,(mode,base,names) in enumerate(paths):
    draw.text((12,top+(i+.5)*h),mode,fill='#24303a',font=font,anchor='lm')
    for j,name in enumerate(names):
        with Image.open(base/name) as img:
            img.thumbnail((w-6,h-8),Image.Resampling.LANCZOS)
            sheet.paste(img,(int(side+j*w+(w-img.width)/2),int(top+i*h+(h-img.height)/2)))
sheet.save(res/'native'/'matrix.jpg',quality=92,optimize=True)
